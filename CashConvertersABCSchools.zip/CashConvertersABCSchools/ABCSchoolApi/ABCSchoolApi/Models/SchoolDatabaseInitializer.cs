﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace ABCSchoolApi.Models
{
    public class SchoolDatabaseInitializer 
    {
        public static void Initialize(SchoolContext context)
        {

            context.Database.EnsureCreated();
            // Look for any students.
            if (context.Students.Any())
            {
                return;   // DB has been seeded
            }
            var students = new Student[]
           {
            new Student{FirstName="Carson",LastName="Alexander",ContactNumber="2005-09-01"},
            new Student{FirstName="Meredith",LastName="Alonso",ContactNumber="2002-09-01"},
            new Student{FirstName="Arturo",LastName="Anand",ContactNumber="2003-09-01"},
            new Student{FirstName="Gytis",LastName="Barzdukas",ContactNumber="2002-09-01"},
            new Student{FirstName="Yan",LastName="Li",ContactNumber="2002-09-01"},
            new Student{FirstName="Peggy",LastName="Justice",ContactNumber="2001-09-01"},
            new Student{FirstName="Laura",LastName="Norman",ContactNumber="2003-09-01"},
            new Student{FirstName="Nino",LastName="Olivetto",ContactNumber="2005-09-01"}
           };
            foreach (Student s in students)
            {
                context.Students.Add(s);
            }
            context.SaveChanges();

            var subject = new Subject[]
           {
            new Subject{SubjectID=1050,Title="Physics"},
            new Subject{SubjectID=4022,Title="Mathematics"},
            new Subject{SubjectID=4041,Title="Accounting"},
            new Subject{SubjectID=1045,Title="English"},
            new Subject{SubjectID=3141,Title="Life Orientation"},
            new Subject{SubjectID=2021,Title="Information Technology"},
            new Subject{SubjectID=2042,Title="Economics"}
           };
            foreach (Subject c in subject)
            {
                context.Subjects.Add(c);
            }
            context.SaveChanges();

            var studentSubject = new StudentSubject[]
            {
            new StudentSubject{StudentID=1,SubjectID=1050},
            new StudentSubject{StudentID=1,SubjectID=4022},
            new StudentSubject{StudentID=1,SubjectID=4041},
            new StudentSubject{StudentID=2,SubjectID=1045},
            new StudentSubject{StudentID=2,SubjectID=3141},
            new StudentSubject{StudentID=2,SubjectID=2021,},
            new StudentSubject{StudentID=3,SubjectID=1050},
            new StudentSubject{StudentID=4,SubjectID=1050},
            new StudentSubject{StudentID=4,SubjectID=4022},
            new StudentSubject{StudentID=5,SubjectID=4041},
            new StudentSubject{StudentID=6,SubjectID=1045},
            new StudentSubject{StudentID=7,SubjectID=3141},
            };
            foreach (StudentSubject e in studentSubject)
            {
                context.StudentSubjects.Add(e);
            }
            context.SaveChanges();


        }
    }
}
