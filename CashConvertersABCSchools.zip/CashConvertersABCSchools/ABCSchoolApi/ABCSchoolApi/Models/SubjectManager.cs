﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ABCSchoolApi.Models.Repository;

namespace ABCSchoolApi.Models
{
  
        public class SubjectManager : IDataRepository<Subject>
        {
            readonly SchoolContext _schoolContext;
            public SubjectManager(SchoolContext context)
            {
                _schoolContext = context;
            }
            public IEnumerable<Subject> GetAll()
            {
                return _schoolContext.Subjects.ToList();
            }
            public Subject Get(int id)
            {
                return _schoolContext.Subjects
                      .FirstOrDefault(e => e.SubjectID == id);
            }
            public void Add(Subject entity)
            {
                _schoolContext.Subjects.Add(entity);
                _schoolContext.SaveChanges();
            }
            public void Update(Subject subjects, Subject entity)
            {
            subjects.Title = entity.Title;
           
                _schoolContext.SaveChanges();
            }
            public void Delete(Subject Subjects)
            {
                _schoolContext.Subjects.Remove(Subjects);
                _schoolContext.SaveChanges();
            }
        
    }
}
