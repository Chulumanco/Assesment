﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ABCSchoolApi.Models
{
    public class Student
    {
        public int StudentId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        //public DateTime EnrollmentDate { get; set; }
        public string ContactNumber { get; set; }

        public ICollection<StudentSubject> StudentSubjects { get; set; }
    }
}
