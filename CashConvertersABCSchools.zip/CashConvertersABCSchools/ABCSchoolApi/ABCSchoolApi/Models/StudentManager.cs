﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ABCSchoolApi.Models.Repository;

namespace ABCSchoolApi.Models
{
    public class StudentManager : IDataRepository<Student>
    {
        readonly SchoolContext _schoolContext;
        public StudentManager(SchoolContext context)
        {
            _schoolContext = context;
        }
        public IEnumerable<Student> GetAll()
        {
            return _schoolContext.Students.ToList();
        }
        public Student Get(int id)
        {
            return _schoolContext.Students
                  .FirstOrDefault(e => e.StudentId == id);
        }
        public void Add(Student entity)
        {
            _schoolContext.Students.Add(entity);
            _schoolContext.SaveChanges();
        }
        public void Update(Student students, Student entity)
        {
            students.FirstName = entity.FirstName;
            students.LastName = entity.LastName;
            students.EnrollmentDate = entity.EnrollmentDate;
            students.ContactNumber = entity.ContactNumber;
            _schoolContext.SaveChanges();
        }
        public void Delete(Student students)
        {
            _schoolContext.Students.Remove(students);
            _schoolContext.SaveChanges();
        }
    }
}
